class HillClimbingProblem:
    def initial_state(self):
        """Initial state of the problem."""
        pass

    def shuffle(self):
        """Shuffle state."""
        pass

    def best_neighbour(self,):
        """Find best neighbour."""
        pass

    def value(self):
        """Get value of specified state."""
        pass

    def plot():
        pass
