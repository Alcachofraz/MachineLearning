class SimulatedAnealingProblem:
    def initial_state(self):
        """Initial state of the problem. Takes the size 'size'"""
        pass

    def random_neighbour(self):
        """Find random neighbour of 'state'."""
        pass

    def value(self):
        """Get value of 'state'."""
        pass

    def plot():
        pass
