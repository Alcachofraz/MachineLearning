class GeneticProblem:
    def population():
        pass

    def crossover():
        pass

    def mutate():
        pass

    def fitness():
        pass

    def value():
        pass

    def plot():
        pass
