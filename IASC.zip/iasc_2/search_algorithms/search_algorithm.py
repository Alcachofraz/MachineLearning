class SearchAlgorithm:
    initial_state = None
    initial_value = None
    final_state = None
    final_value = None

    def search():
        """
        Perform search.
        """
        pass
